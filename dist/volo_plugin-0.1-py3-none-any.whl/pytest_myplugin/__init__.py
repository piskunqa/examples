# volo_pytest/__init__.py

# Автоматическая регистрация плагина
from .plugin import *