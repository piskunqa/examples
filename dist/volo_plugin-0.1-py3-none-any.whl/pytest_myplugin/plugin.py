import pytest

def pytest_configure(config):
    print("Плагин pytest-myplugin инициализирован!")

@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    print(f"Начинается тест: {item.name}")