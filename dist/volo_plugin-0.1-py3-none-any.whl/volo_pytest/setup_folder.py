import os

def create_plugin_folders():
    target_dir = os.getcwd()
    test_dir = os.path.join(target_dir, "test")
    if not os.path.exists(test_dir):
        os.makedirs(test_dir, exist_ok=True)
        with open(os.path.join(test_dir, "example.py"), "w") as f:
            f.write("""def test_example(volo, pages, libs):
    print(volo)
    pages.example_page.exemple()
    libs.example_lib.exemple()
""")

        with open(os.path.join(target_dir, "conftest.py"), "w") as f:
            f.write("""""")

    pages_dir = os.path.join(target_dir, "pages")
    if not os.path.exists(pages_dir):
        os.makedirs(pages_dir, exist_ok=True)
        with open(os.path.join(pages_dir, "__init__.py"), "w") as f:
            f.write("""import importlib
import os

__all__ = []

current_dir = os.path.dirname(__file__)
for filename in os.listdir(current_dir):
    if filename.endswith(".py") and filename != "__init__.py":
        module_name = filename[:-3]
        module = importlib.import_module(f".{module_name}", package=__name__)
        globals()[module_name] = module
        __all__.append(module_name)""")
        with open(os.path.join(pages_dir, "example_page.py"), "w") as f:
            f.write("""def exemple():
    print("example page")
""")

    libs_dir = os.path.join(target_dir, "libs")
    if not os.path.exists(libs_dir):
        os.makedirs(libs_dir, exist_ok=True)
        with open(os.path.join(libs_dir, "__init__.py"), "w") as f:
            f.write("""import importlib
import os

__all__ = []

current_dir = os.path.dirname(__file__)
for filename in os.listdir(current_dir):
    if filename.endswith(".py") and filename != "__init__.py":
        module_name = filename[:-3]
        module = importlib.import_module(f".{module_name}", package=__name__)
        globals()[module_name] = module
        __all__.append(module_name)""")
        with open(os.path.join(libs_dir, "example_lib.py"), "w") as f:
            f.write("""def exemple():
    print("example lib")""")


    with open(os.path.join(target_dir, "pytest.ini"), "w") as f:
        f.write("""[pytest]
log_cli = 1
log_cli_level = INFO
log_cli_format = %(asctime)s [%(levelname)s] - %(message)s
python_files=*.py
python_functions=*_test test_* check* exam_*
addopts = -v -s""")

