import os


def create_plugin_folders():
    target_dir = os.getcwd()
    test_dir = os.path.join(target_dir, "test")
    if not os.path.exists(test_dir):
        os.makedirs(test_dir, exist_ok=True)
        with open(os.path.join(test_dir, "example.py"), "w") as f:
            f.write("""def test_example(volo, pages, libs):
    print(volo)
    pages.example_page.exemple()
    libs.example_lib.exemple()
""")

        with open(os.path.join(target_dir, "conftest.py"), "w") as f:
            f.write("""""")

    pages_dir = os.path.join(target_dir, "pages")
    if not os.path.exists(pages_dir):
        os.makedirs(pages_dir, exist_ok=True)
        with open(os.path.join(pages_dir, "__init__.py"), "w") as f:
            f.write("""import os
import importlib.util
import sys
import types

__all__ = []

package_dir = os.path.dirname(__file__)
package_name = __name__

for root, _, files in os.walk(package_dir):
    rel_path = os.path.relpath(root, package_dir)
    rel_parts = [] if rel_path == '.' else rel_path.replace(os.sep, '.').split('.')

    for file in files:
        if file.endswith('.py') and file != '__init__.py':
            module_name = file[:-3]
            module_parts = rel_parts + [module_name]
            dotted_name = '.'.join(module_parts)
            full_module_name = f"{package_name}.{dotted_name}"
            __all__.append(dotted_name)
            file_path = os.path.join(root, file)
            spec = importlib.util.spec_from_file_location(full_module_name, file_path)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                sys.modules[full_module_name] = module
                current = sys.modules[package_name]
                for i, part in enumerate(module_parts[:-1]):
                    sub_module_name = f"{package_name}." + ".".join(module_parts[:i + 1])
                    if not hasattr(current, part):
                        fake_module = types.ModuleType(sub_module_name)
                        setattr(current, part, fake_module)
                        sys.modules[sub_module_name] = fake_module
                    current = getattr(current, part)
                setattr(current, module_parts[-1], module)
""")

    with open(os.path.join(pages_dir, "exemple_page.py"), "w") as f:
        f.write("""def exemple():
    print("exemple page")""")

    libs_dir = os.path.join(target_dir, "libs")
    if not os.path.exists(libs_dir):
        os.makedirs(libs_dir, exist_ok=True)
        with open(os.path.join(libs_dir, "__init__.py"), "w") as f:
            f.write("""import os
import importlib.util
import sys
import types

__all__ = []

package_dir = os.path.dirname(__file__)
package_name = __name__

for root, _, files in os.walk(package_dir):
    rel_path = os.path.relpath(root, package_dir)
    rel_parts = [] if rel_path == '.' else rel_path.replace(os.sep, '.').split('.')

    for file in files:
        if file.endswith('.py') and file != '__init__.py':
            module_name = file[:-3]
            module_parts = rel_parts + [module_name]
            dotted_name = '.'.join(module_parts)
            full_module_name = f"{package_name}.{dotted_name}"
            __all__.append(dotted_name)
            file_path = os.path.join(root, file)
            spec = importlib.util.spec_from_file_location(full_module_name, file_path)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                sys.modules[full_module_name] = module
                current = sys.modules[package_name]
                for i, part in enumerate(module_parts[:-1]):
                    sub_module_name = f"{package_name}." + ".".join(module_parts[:i + 1])
                    if not hasattr(current, part):
                        fake_module = types.ModuleType(sub_module_name)
                        setattr(current, part, fake_module)
                        sys.modules[sub_module_name] = fake_module
                    current = getattr(current, part)
                setattr(current, module_parts[-1], module)
""")

    with open(os.path.join(libs_dir, "exemple_lib.py"), "w") as f:
        f.write("""def exemple():
    print("exemple lib")""")


    with open(os.path.join(target_dir, "pytest.ini"), "w") as f:
        f.write("""[pytest]
log_cli = 1
log_cli_level = INFO
log_cli_format = %(asctime)s [%(levelname)s] - %(message)s
python_files=*.py
python_functions=*_test test_* check* exam_*
addopts = -v -s""")
