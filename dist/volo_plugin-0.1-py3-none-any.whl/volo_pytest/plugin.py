import os

import pytest
import sys
import importlib

p = None
l = None


def pytest_configure(config):
    project_root = str(config.rootpath)
    global p
    global l

    package_name = "pages"
    package_dir = os.path.join(project_root, package_name)
    init_file = os.path.join(package_dir, "__init__.py")

    if os.path.exists(init_file):
        spec = importlib.util.spec_from_file_location(package_name, init_file)
        module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = module
        spec.loader.exec_module(module)
        p = module

    package_name = "libs"
    package_dir = os.path.join(project_root, package_name)
    init_file = os.path.join(package_dir, "__init__.py")

    if os.path.exists(init_file):
        spec = importlib.util.spec_from_file_location(package_name, init_file)
        module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = module
        spec.loader.exec_module(module)
        l = module


#
# @pytest.hookimpl(tryfirst=True)
# def pytest_sessionstart(session):
#     """
#     Вызывается в начале сессии pytest.
#     """
#     print("Начало сессии pytest!")
#
#
# @pytest.hookimpl(hookwrapper=True)
# def pytest_runtest_makereport(item, call):
#     """
#     Вызывается после каждого теста.
#     """
#     outcome = yield
#     report = outcome.get_result()
#     if report.when == "call":
#         if report.failed:
#             print(f"Тест {item.name} упал!")
#         elif report.passed:
#             print(f"Тест {item.name} успешно пройден!")
#
#
# @pytest.hookimpl(hookwrapper=True)
# def pytest_terminal_summary(terminalreporter, exitstatus, config):
#     """
#     Вызывается в конце сессии pytest, перед выводом итогов в терминал.
#     """
#     yield
#     print("Конец сессии pytest!")

@pytest.fixture(scope="session", autouse=True)
def volo():
    yield "Здесь могла быть ваша реклама!"


@pytest.fixture(scope="session", autouse=True)
def pages():
    yield p


@pytest.fixture(scope="session", autouse=True)
def libs():
    yield l
