import os

import pytest
import sys
import importlib
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

p = None
l = None
webdriver_instance: webdriver.Chrome = None


def pytest_configure(config):
    project_root = str(config.rootpath)
    global p
    global l

    package_name = "pages"
    package_dir = os.path.join(project_root, package_name)
    init_file = os.path.join(package_dir, "__init__.py")

    if os.path.exists(init_file):
        spec = importlib.util.spec_from_file_location(package_name, init_file)
        module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = module
        spec.loader.exec_module(module)
        p = module

    package_name = "libs"
    package_dir = os.path.join(project_root, package_name)
    init_file = os.path.join(package_dir, "__init__.py")

    if os.path.exists(init_file):
        spec = importlib.util.spec_from_file_location(package_name, init_file)
        module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = module
        spec.loader.exec_module(module)
        l = module


@pytest.hookimpl(tryfirst=True)
def pytest_sessionstart(session):
    print("Start pytest!")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == "call":
        if report.failed:
            print(f"Test {item.name} FAILS!")
        elif report.passed:
            print(f"Test {item.name} PASS!")


def pytest_sessionfinish(session, exitstatus):
    global webdriver_instance
    if webdriver_instance is not None:
        webdriver_instance.quit()
        print("[plugin] 🔻 WebDriver closed!")
    print("End pytest!")


@pytest.hookimpl(hookwrapper=True)
def pytest_terminal_summary(terminalreporter, exitstatus, config):
    outcome = yield


@pytest.fixture(scope="function")
def chrome_browser() -> webdriver.Chrome:
    global webdriver_instance
    if webdriver_instance is None:
        chrome_options = Options()
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        try:
            webdriver_instance = webdriver.Chrome(options=chrome_options)
            print("[plugin] ✅ WebDriver created")
        except Exception as e:
            print(f"[plugin] ❌ WebDriver error: {e}")
            webdriver_instance = None
        if webdriver_instance is None:
            pytest.fail("WebDriver not initialized")
        yield webdriver_instance
        try:
            webdriver_instance.quit()
            webdriver_instance = None
            print("[plugin] 🔻 WebDriver closed!")
        except Exception as e:
            print(f"[plugin] ❌ WebDriver error: {e}")


@pytest.fixture(scope="session", autouse=True)
def volo():
    yield "Здесь могла быть ваша реклама!"


@pytest.fixture(scope="session", autouse=True)
def pages():
    yield p


@pytest.fixture(scope="session", autouse=True)
def libs():
    yield l
